export * from './GameControlButtonsPanel';
export { default } from './GameControlButtonsPanel';
