export * from './GameLostModal';
export { default } from './GameLostModal';
