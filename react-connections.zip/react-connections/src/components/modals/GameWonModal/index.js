export * from './GameWonModal';
export { default } from './GameWonModal';
