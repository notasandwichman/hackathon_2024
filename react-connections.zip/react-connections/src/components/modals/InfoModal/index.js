export * from './InfoModal';
export { default } from './InfoModal';
